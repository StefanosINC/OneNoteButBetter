﻿namespace CLCMilestone
{
    partial class ViewCalender
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mondayTextBox = new System.Windows.Forms.RichTextBox();
            this.tuesdayTextBox1 = new System.Windows.Forms.RichTextBox();
            this.wednesdayTextBox = new System.Windows.Forms.RichTextBox();
            this.fridayTextBox = new System.Windows.Forms.RichTextBox();
            this.thursdayTextBox = new System.Windows.Forms.RichTextBox();
            this.saturdayTextBox = new System.Windows.Forms.RichTextBox();
            this.sundayTextBox = new System.Windows.Forms.RichTextBox();
            this.Btn_BackIcon = new FontAwesome.Sharp.IconButton();
            this.NewNoteIconbtn = new FontAwesome.Sharp.IconButton();
            this.label8 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // mondayTextBox
            // 
            this.mondayTextBox.Location = new System.Drawing.Point(12, 62);
            this.mondayTextBox.Name = "mondayTextBox";
            this.mondayTextBox.ReadOnly = true;
            this.mondayTextBox.Size = new System.Drawing.Size(150, 330);
            this.mondayTextBox.TabIndex = 7;
            this.mondayTextBox.Text = "";
            this.mondayTextBox.TextChanged += new System.EventHandler(this.mondayTextBox_TextChanged);
            // 
            // tuesdayTextBox1
            // 
            this.tuesdayTextBox1.Location = new System.Drawing.Point(190, 62);
            this.tuesdayTextBox1.Name = "tuesdayTextBox1";
            this.tuesdayTextBox1.ReadOnly = true;
            this.tuesdayTextBox1.Size = new System.Drawing.Size(150, 330);
            this.tuesdayTextBox1.TabIndex = 8;
            this.tuesdayTextBox1.Text = "";
            // 
            // wednesdayTextBox
            // 
            this.wednesdayTextBox.Location = new System.Drawing.Point(358, 62);
            this.wednesdayTextBox.Name = "wednesdayTextBox";
            this.wednesdayTextBox.ReadOnly = true;
            this.wednesdayTextBox.Size = new System.Drawing.Size(150, 330);
            this.wednesdayTextBox.TabIndex = 9;
            this.wednesdayTextBox.Text = "";
            // 
            // fridayTextBox
            // 
            this.fridayTextBox.Location = new System.Drawing.Point(704, 62);
            this.fridayTextBox.Name = "fridayTextBox";
            this.fridayTextBox.ReadOnly = true;
            this.fridayTextBox.Size = new System.Drawing.Size(150, 330);
            this.fridayTextBox.TabIndex = 10;
            this.fridayTextBox.Text = "";
            // 
            // thursdayTextBox
            // 
            this.thursdayTextBox.Location = new System.Drawing.Point(529, 62);
            this.thursdayTextBox.Name = "thursdayTextBox";
            this.thursdayTextBox.ReadOnly = true;
            this.thursdayTextBox.Size = new System.Drawing.Size(150, 330);
            this.thursdayTextBox.TabIndex = 11;
            this.thursdayTextBox.Text = "";
            // 
            // saturdayTextBox
            // 
            this.saturdayTextBox.Location = new System.Drawing.Point(875, 62);
            this.saturdayTextBox.Name = "saturdayTextBox";
            this.saturdayTextBox.ReadOnly = true;
            this.saturdayTextBox.Size = new System.Drawing.Size(150, 330);
            this.saturdayTextBox.TabIndex = 12;
            this.saturdayTextBox.Text = "";
            // 
            // sundayTextBox
            // 
            this.sundayTextBox.Location = new System.Drawing.Point(1054, 62);
            this.sundayTextBox.Name = "sundayTextBox";
            this.sundayTextBox.ReadOnly = true;
            this.sundayTextBox.Size = new System.Drawing.Size(150, 330);
            this.sundayTextBox.TabIndex = 13;
            this.sundayTextBox.Text = "";
            // 
            // Btn_BackIcon
            // 
            this.Btn_BackIcon.FlatAppearance.BorderSize = 0;
            this.Btn_BackIcon.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Btn_BackIcon.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Btn_BackIcon.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.Btn_BackIcon.IconChar = FontAwesome.Sharp.IconChar.ChevronCircleLeft;
            this.Btn_BackIcon.IconColor = System.Drawing.Color.White;
            this.Btn_BackIcon.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.Btn_BackIcon.IconSize = 50;
            this.Btn_BackIcon.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.Btn_BackIcon.Location = new System.Drawing.Point(12, 403);
            this.Btn_BackIcon.Name = "Btn_BackIcon";
            this.Btn_BackIcon.Size = new System.Drawing.Size(138, 56);
            this.Btn_BackIcon.TabIndex = 16;
            this.Btn_BackIcon.Text = "Return to Home";
            this.Btn_BackIcon.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.Btn_BackIcon.UseVisualStyleBackColor = true;
            this.Btn_BackIcon.Click += new System.EventHandler(this.Btn_BackIcon_Click);
            // 
            // NewNoteIconbtn
            // 
            this.NewNoteIconbtn.FlatAppearance.BorderSize = 0;
            this.NewNoteIconbtn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.NewNoteIconbtn.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NewNoteIconbtn.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.NewNoteIconbtn.IconChar = FontAwesome.Sharp.IconChar.Plus;
            this.NewNoteIconbtn.IconColor = System.Drawing.Color.White;
            this.NewNoteIconbtn.IconFont = FontAwesome.Sharp.IconFont.Auto;
            this.NewNoteIconbtn.IconSize = 50;
            this.NewNoteIconbtn.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.NewNoteIconbtn.Location = new System.Drawing.Point(1064, 392);
            this.NewNoteIconbtn.Name = "NewNoteIconbtn";
            this.NewNoteIconbtn.Size = new System.Drawing.Size(161, 67);
            this.NewNoteIconbtn.TabIndex = 18;
            this.NewNoteIconbtn.Text = "Create Note";
            this.NewNoteIconbtn.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.NewNoteIconbtn.UseVisualStyleBackColor = true;
            this.NewNoteIconbtn.Click += new System.EventHandler(this.NewNoteIconbtn_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Tai Le", 20.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label8.Location = new System.Drawing.Point(37, 9);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(113, 34);
            this.label8.TabIndex = 19;
            this.label8.Text = "Monday";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Tai Le", 20.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label1.Location = new System.Drawing.Point(891, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(119, 34);
            this.label1.TabIndex = 20;
            this.label1.Text = "Saturday";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Tai Le", 20.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label9.Location = new System.Drawing.Point(733, 8);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(87, 34);
            this.label9.TabIndex = 21;
            this.label9.Text = "Friday";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Tai Le", 20.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label10.Location = new System.Drawing.Point(548, 9);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(122, 34);
            this.label10.TabIndex = 22;
            this.label10.Text = "Thursday";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Tai Le", 20.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label11.Location = new System.Drawing.Point(355, 9);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(153, 34);
            this.label11.TabIndex = 23;
            this.label11.Text = "Wednesday";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Tai Le", 20.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label12.Location = new System.Drawing.Point(212, 8);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(112, 34);
            this.label12.TabIndex = 24;
            this.label12.Text = "Tuesday";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Tai Le", 20.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.label2.Location = new System.Drawing.Point(1082, 9);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(102, 34);
            this.label2.TabIndex = 25;
            this.label2.Text = "Sunday";
            // 
            // ViewCalender
            // 
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(30)))), ((int)(((byte)(68)))));
            this.ClientSize = new System.Drawing.Size(1227, 462);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.NewNoteIconbtn);
            this.Controls.Add(this.Btn_BackIcon);
            this.Controls.Add(this.sundayTextBox);
            this.Controls.Add(this.saturdayTextBox);
            this.Controls.Add(this.thursdayTextBox);
            this.Controls.Add(this.fridayTextBox);
            this.Controls.Add(this.wednesdayTextBox);
            this.Controls.Add(this.tuesdayTextBox1);
            this.Controls.Add(this.mondayTextBox);
            this.Name = "ViewCalender";
            this.Load += new System.EventHandler(this.ViewCalender_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }


        #endregion
        private System.Windows.Forms.RichTextBox mondayTextBox;
        private System.Windows.Forms.RichTextBox tuesdayTextBox1;
        private System.Windows.Forms.RichTextBox wednesdayTextBox;
        private System.Windows.Forms.RichTextBox fridayTextBox;
        private System.Windows.Forms.RichTextBox thursdayTextBox;
        private System.Windows.Forms.RichTextBox saturdayTextBox;
        private System.Windows.Forms.RichTextBox sundayTextBox;
        private FontAwesome.Sharp.IconButton Btn_BackIcon;
        private FontAwesome.Sharp.IconButton NewNoteIconbtn;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label2;
    }
}